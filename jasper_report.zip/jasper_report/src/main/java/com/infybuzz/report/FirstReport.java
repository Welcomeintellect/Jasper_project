package com.infybuzz.report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class FirstReport {

    public static void main(String args[]){

        try{

            String filePath="/home/maheshbeeram/OfficeWork/CTOWorkSpace/jasper_report/src/main/resources/FirstReport.jrxml";
            Map<String,Object> parameters=new HashMap<String,Object>();
            parameters.put("empName", "MaheshB");
            Student student=new Student(1L,"Mahesh","B","01","Ch1");
            Student student1=new Student(2L,"Java","B","02","Ch2");

            List<Student> list=new ArrayList<Student>();
            list.add(student);
            list.add(student1);

            JRBeanCollectionDataSource dataSource=new JRBeanCollectionDataSource(list);
            String outPath="home/maheshbeeram/JaspersoftWorkspace/FirstReport.pdf";

            JasperReport report=JasperCompileManager.compileReport(filePath);

            JasperPrint print =JasperFillManager.fillReport(report,parameters,dataSource);

            JasperExportManager.exportReportToPdfFile(print,"/home/maheshbeeram/jasperreportGeneratorTest/FirstReport.pdf");
            System.out.println("Report Generated");
        }
        catch(Exception e){

            e.printStackTrace();
        }

    }
    
}
